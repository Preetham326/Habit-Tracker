import React from 'react';
import AddHabitForm from './components/AddHabitForm';
import HabitList from './components/HabitList';
import QuoteDisplay from './components/QuoteDisplay';
import RecommendedHabits from './components/RecommendedHabits';
import ProgressOverview from './components/ProgressOverview';

function App() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', maxWidth: '800px', margin: '0 auto', padding: '2rem', width: '100%' }}>
      <header style={{ marginBottom: '2rem', textAlign: 'center' }}>
        <h1 style={{ fontSize: '3rem', fontWeight: 'bold', background: 'linear-gradient(to right, var(--primary), var(--accent))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: '0.5rem' }}>
          Habit Builder
        </h1>
        <p style={{ color: 'var(--text-secondary)' }}>Build better habits, one day at a time.</p>
      </header>

      <main style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
        <QuoteDisplay />
        <ProgressOverview />
        <div>
          <AddHabitForm />
          <RecommendedHabits />
        </div>

        <div>
          <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem', color: 'var(--text-primary)' }}>My Habits</h2>
          <HabitList />
        </div>
      </main>
    </div>
  );
}

export default App;
