import React from 'react';
import { useHabits } from '../context/HabitContext';
import HabitCard from './HabitCard';

export default function HabitList() {
    const { habits } = useHabits();

    if (habits.length === 0) {
        return (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-secondary)' }}>
                <p>No habits yet. Start small!</p>
            </div>
        );
    }

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {habits.map(habit => (
                <HabitCard key={habit.id} habit={habit} />
            ))}
        </div>
    );
}
