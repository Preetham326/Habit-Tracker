import React from 'react';
import { useHabits } from '../context/HabitContext';
import './components.css';

export default function ProgressOverview() {
    const { habits } = useHabits();

    if (habits.length === 0) return null;

    const today = new Date().toISOString().split('T')[0];
    const totalHabits = habits.length;
    const completedToday = habits.filter(h => h.completedDates.includes(today)).length;
    const completionRate = Math.round((completedToday / totalHabits) * 100);

    return (
        <div className="card" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-card)' }}>
            <div>
                <h4 style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Daily Progress
                </h4>
                <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
                    {completedToday} <span style={{ color: 'var(--text-secondary)', fontSize: '1rem' }}>/ {totalHabits} habits</span>
                </div>
            </div>

            <div style={{ position: 'relative', width: '60px', height: '60px' }}>
                <svg width="60" height="60" viewBox="0 0 36 36">
                    <path
                        d="M18 2.0845
              a 15.9155 15.9155 0 0 1 0 31.831
              a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="#1e293b" // bg-card darker
                        strokeWidth="3"
                    />
                    <path
                        d="M18 2.0845
              a 15.9155 15.9155 0 0 1 0 31.831
              a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="var(--primary)"
                        strokeWidth="3"
                        strokeDasharray={`${completionRate}, 100`}
                        strokeLinecap="round"
                        transform="rotate(0 18 18)"
                        style={{ transition: 'stroke-dasharray 0.5s ease' }}
                    />
                </svg>
                <div style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '0.75rem',
                    fontWeight: 'bold'
                }}>
                    {completionRate}%
                </div>
            </div>
        </div>
    );
}
