import React from 'react';
import { useHabits } from '../context/HabitContext';
import './components.css';

const RECOMMENDATIONS = [
    { name: "Drink Water 💧", frequency: "daily" },
    { name: "Read 30 Mins 📚", frequency: "daily" },
    { name: "Workout 💪", frequency: "daily" },
    { name: "Meditate 🧘", frequency: "daily" },
    { name: "No Sugar 🍬", frequency: "daily" },
    { name: "Walk 10k Steps 👣", frequency: "daily" },
    { name: "Journal ✍️", frequency: "daily" },
    { name: "Weekly Plan 🗓️", frequency: "weekly" }
];

export default function RecommendedHabits() {
    const { addHabit, habits } = useHabits();

    const handleAdd = (rec) => {
        // Avoid duplicates
        if (habits.some(h => h.name === rec.name)) return;
        addHabit(rec.name, rec.frequency);
    };

    return (
        <div style={{ marginBottom: '2rem' }}>
            <p style={{
                color: 'var(--text-secondary)',
                fontSize: '0.875rem',
                marginBottom: '0.75rem',
                fontWeight: 500
            }}>
                Suggestions
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {RECOMMENDATIONS.map((rec) => {
                    const isAdded = habits.some(h => h.name === rec.name);
                    return (
                        <button
                            key={rec.name}
                            onClick={() => handleAdd(rec)}
                            disabled={isAdded}
                            className={`recommendation-chip ${isAdded ? 'added' : ''}`}
                            title={isAdded ? "Already added" : "Add this habit"}
                        >
                            {rec.name}
                        </button>
                    );
                })}
            </div>
        </div>
    );
}
