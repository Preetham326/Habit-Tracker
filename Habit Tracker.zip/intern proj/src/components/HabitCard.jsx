import React from 'react';
import { useHabits } from '../context/HabitContext';
import { calculateStreak } from '../utils';
import './components.css';

export default function HabitCard({ habit }) {
    const { toggleHabitCompletion, deleteHabit } = useHabits();

    // Calculate if completed today
    const today = new Date().toISOString().split('T')[0];
    const isCompleted = habit.completedDates.includes(today);

    // Use robust streak calculation
    const streak = calculateStreak(habit.completedDates);
    const totalCount = habit.completedDates.length;

    return (
        <div className="card habit-item">
            <button
                className={`check-btn ${isCompleted ? 'completed' : ''}`}
                onClick={() => toggleHabitCompletion(habit.id)}
                aria-label={isCompleted ? "Mark as incomplete" : "Mark as complete"}
            >
                {isCompleted && "✓"}
            </button>

            <div className="habit-info">
                <h3 className="habit-name" style={{ textDecoration: isCompleted ? 'line-through' : 'none', color: isCompleted ? 'var(--text-secondary)' : 'var(--text-primary)' }}>
                    {habit.name}
                </h3>
                <div className="habit-meta">
                    <span>{habit.frequency}</span>
                    <span className="streak-badge" title={`Total Completions: ${totalCount}`}>
                        🔥 {streak} day streak
                    </span>
                </div>
            </div>

            <button
                className="btn btn-danger"
                onClick={() => deleteHabit(habit.id)}
                title="Delete Habit"
            >
                🗑️
            </button>
        </div>
    );
}
