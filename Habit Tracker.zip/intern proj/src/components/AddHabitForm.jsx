import React, { useState } from 'react';
import { useHabits } from '../context/HabitContext';
import './components.css';

export default function AddHabitForm() {
    const [name, setName] = useState('');
    const [frequency, setFrequency] = useState('daily');
    const { addHabit } = useHabits();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!name.trim()) return;

        addHabit(name, frequency);
        setName('');
    };

    return (
        <div className="card" style={{ marginBottom: '2rem' }}>
            <h3 style={{ marginBottom: '1rem', color: 'var(--text-secondary)', textTransform: 'uppercase', fontSize: '0.875rem', letterSpacing: '0.05em' }}>
                New Habit
            </h3>
            <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                <input
                    type="text"
                    className="form-input"
                    style={{ flex: 1, marginBottom: 0 }}
                    placeholder="What do you want to achieve?"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <select
                    className="form-select"
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value)}
                >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                </select>
                <button type="submit" className="btn btn-primary">
                    Add Habit
                </button>
            </form>
        </div>
    );
}
