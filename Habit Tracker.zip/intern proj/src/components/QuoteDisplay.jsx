import React, { useState, useEffect } from 'react';
import './components.css';

export default function QuoteDisplay() {
    const [quote, setQuote] = useState({ content: "The secret of getting ahead is getting started.", author: "Mark Twain" });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchQuote = async () => {
            try {
                const response = await fetch('https://api.quotable.io/random?tags=motivational,inspirational');
                if (response.ok) {
                    const data = await response.json();
                    setQuote({ content: data.content, author: data.author });
                }
            } catch (error) {
                console.error('Error fetching quote:', error);
                // Fallback is already set in initial state
            } finally {
                setLoading(false);
            }
        };

        fetchQuote();
    }, []);

    return (
        <div className="card" style={{
            background: 'linear-gradient(135deg, var(--bg-card), rgba(99, 102, 241, 0.1))',
            borderLeft: '4px solid var(--accent)',
            position: 'relative',
            overflow: 'hidden'
        }}>
            <div style={{ position: 'relative', zIndex: 1 }}>
                <p style={{
                    fontSize: '1.25rem',
                    fontStyle: 'italic',
                    marginBottom: '1rem',
                    lineHeight: '1.6'
                }}>
                    "{quote.content}"
                </p>
                <p style={{
                    fontSize: '0.875rem',
                    color: 'var(--text-secondary)',
                    textAlign: 'right',
                    fontWeight: 600
                }}>
                    — {quote.author}
                </p>
            </div>
            {/* Decorative element */}
            <div style={{
                position: 'absolute',
                top: '-1rem',
                right: '1rem',
                fontSize: '4rem',
                opacity: 0.1,
                pointerEvents: 'none'
            }}>
                ❝
            </div>
        </div>
    );
}
