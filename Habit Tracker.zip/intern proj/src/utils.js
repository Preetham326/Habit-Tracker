/**
 * Calculates the current streak of consecutive days ending today or yesterday.
 * @param {string[]} completedDates - Array of ISO date strings (YYYY-MM-DD)
 * @param {string} frequency - 'daily' or 'weekly'
 * @returns {number} Current streak count
 */
export function calculateStreak(completedDates) {
    if (!completedDates || completedDates.length === 0) return 0;

    const sorted = [...new Set(completedDates)].sort().reverse();
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    // If not completed today or yesterday, streak is broken (0), unless we want to be lenient
    // For a strict streak: must have done it today or yesterday.
    if (sorted[0] !== today && sorted[0] !== yesterday) {
        return 0;
    }

    let streak = 0;
    // We start checking from today (if completed) or yesterday (if completed) backwards
    let currentDate = new Date();

    // Check if we start counting from today or yesterday
    if (sorted.includes(today)) {
        streak = 1;
        // Move to yesterday for next check
        currentDate.setDate(currentDate.getDate() - 1);
    } else if (sorted.includes(yesterday)) {
        streak = 1;
        // Move to day before yesterday for next check
        currentDate.setDate(currentDate.getDate() - 2);
    } else {
        return 0;
    }

    // Iterate backwards
    while (true) {
        const dateStr = currentDate.toISOString().split('T')[0];
        if (sorted.includes(dateStr)) {
            streak++;
            currentDate.setDate(currentDate.getDate() - 1);
        } else {
            break;
        }
    }

    // Adjust logic slightly: the loop above double counts the start if not careful.
    // Let's rely on a simpler 'consecutive' check on the sorted array.

    // Simpler approach:
    // 1. Filter completedDates to unique, sorted descending.
    // 2. Check if top is today or yesterday. If not, return 0.
    // 3. Iterate and check gap between dates is 1 day.

    return calculateConsecutive(sorted, today, yesterday);
}

function calculateConsecutive(sortedDates, today, yesterday) {
    if (sortedDates.length === 0) return 0;

    let currentStreak = 0;
    let expectedDate = new Date(); // Start checking from today

    // If the latest completion is today
    if (sortedDates[0] === today) {
        currentStreak = 1;
        expectedDate.setDate(expectedDate.getDate() - 1); // Next expect yesterday
    }
    // If latest is yesterday, streak is still alive
    else if (sortedDates[0] === yesterday) {
        currentStreak = 1;
        expectedDate.setDate(expectedDate.getDate() - 2); // Next expect day before yesterday
    }
    else {
        return 0; // Streak broken
    }

    // Continue checking previous dates
    for (let i = 1; i < sortedDates.length; i++) {
        const dateStr = sortedDates[i];
        const expectedStr = expectedDate.toISOString().split('T')[0];

        if (dateStr === expectedStr) {
            currentStreak++;
            expectedDate.setDate(expectedDate.getDate() - 1);
        } else {
            // Gap found
            break;
        }
    }
    return currentStreak;
}
