/* eslint-disable react/prop-types */
import React, { createContext, useContext } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { v4 as uuidv4 } from 'uuid';

const HabitContext = createContext();

export function useHabits() {
    return useContext(HabitContext);
}

export function HabitProvider({ children }) {
    const [habits, setHabits] = useLocalStorage('habits', []);

    // Add a new habit
    const addHabit = (name, frequency = 'daily') => {
        const newHabit = {
            id: uuidv4(),
            name,
            frequency,
            completedDates: [], // Array of ISO date strings (e.g., '2023-10-27')
            createdAt: new Date().toISOString(),
        };
        setHabits([...habits, newHabit]);
    };

    // Delete a habit
    const deleteHabit = (id) => {
        setHabits(habits.filter(habit => habit.id !== id));
    };

    // Toggle completion for a specific date (default today)
    const toggleHabitCompletion = (id, dateStr) => {
        const today = dateStr || new Date().toISOString().split('T')[0];

        setHabits(habits.map(habit => {
            if (habit.id === id) {
                const isCompleted = habit.completedDates.includes(today);
                let newCompletedDates;
                if (isCompleted) {
                    newCompletedDates = habit.completedDates.filter(d => d !== today);
                } else {
                    newCompletedDates = [...habit.completedDates, today];
                }
                return { ...habit, completedDates: newCompletedDates };
            }
            return habit;
        }));
    };

    return (
        <HabitContext.Provider value={{ habits, addHabit, deleteHabit, toggleHabitCompletion }}>
            {children}
        </HabitContext.Provider>
    );
}
